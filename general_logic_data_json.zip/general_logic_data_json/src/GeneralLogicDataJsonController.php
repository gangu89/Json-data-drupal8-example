<?php

namespace Drupal\general_logic_data;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\image\Entity\ImageStyle;
use Drupal\Component\Utility\Html;
use Symfony\Component\HttpFoundation\Request;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Entity\Query\QueryFactory;
// use Drupal\ghl_common_functions\GhlCommonFunctionsController;
use Drupal\Core\Datetime\DrupalDateTime;

/**
 * Controller to get JSON for all search results.
 */
class GeneralLogicDataJsonController extends ControllerBase {
  /**
   * {@inheritdoc}
   */
  protected $entityTypeManager;
  /**
   * {@inheritdoc}
   */
  protected $cacheBackend;
  /**
   * {@inheritdoc}
   */
  protected $entityQuery;

  /**
   * {@inheritdoc}
   */
  public function __construct(EntityTypeManagerInterface $entityTypeManager, CacheBackendInterface $cacheBackend, QueryFactory $entityQuery) {
    $this->entityTypeManager = $entityTypeManager;
    $this->cacheBackend = $cacheBackend;
    $this->entityQuery = $entityQuery;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity.manager'),
      $container->get('cache.default'),
      $container->get('entity.query')
    );
  }
   /**
   * Load Node Data to JSON.
   */
  public function getGenerallogicData() {
    // if ($cache = $this->cacheBackend->get("offer_{$offerID}")) {
    //   return $cache->data;
    // }

    $response = [];
    $ghl_common_functions_obj = new GhlCommonFunctionsController();

    $base_url = Request::createFromGlobals()->getSchemeAndHttpHost();
    $request = \Drupal::request();

    $storage = \Drupal::service('entity_type.manager')->getStorage('node');

    $nids = $storage->getQuery()
        ->condition('type', 'upsell_crosssell_generallogic')
        ->condition('status', 1)
        ->execute();
    foreach ($nids as $nodeID) {              
        $general = $this->entityTypeManager->getStorage('node')->load($nodeID);
        if ($general != NULL && $general->bundle() == "upsell_crosssell_generallogic" && $general->status->value == 1) {
         

          // Loop through generallogic items.
          if ($general->field_generallogic->getValue() != NULL) {
            $general_items = $general->field_generallogic->getValue();
            $general_count = 0;
            foreach ($general_items as $general_item) {
              $p = Paragraph::load($general_item['target_id']);
             // echo '<pre>';print_r($p);exit;
             // if ($p->get('field_amountthreshold_gl')->value != NULL) {
                $response['generalLogic'][$general_count]['amountThreshold'] = $p->get('field_amountthreshold_gl')->value;
                $response['generalLogic'][$general_count]['entryPage'] = $p->get('field_entrypage')->value;
                $response['generalLogic'][$general_count]['logicType'] = $p->get('field_logic_type')->value;
                $response['generalLogic'][$general_count]['priority'] = $p->get('field_priority_')->value;
                $response['generalLogic'][$general_count]['ruleType'] = $p->get('field_ruletype')->value;
               
             // }

            //Banner Paragraph 
            $banner_items = $p->field_banner_genrallogic->getValue();
            $banner_count = 0;
            foreach ($banner_items as $banner_item) {
                $banner_data = Paragraph::load($banner_item['target_id']);               
                // echo '<pre>';print_r($banner_data);exit;
              if ($banner_data->field_bannerimage->getValue() != NULL) {
                  $image_id = $banner_data->field_bannerimage->getValue();
                  $uri = $banner_data->get('field_bannerimage')->entity->getFileUri();
                  $url = file_create_url($uri);
                  $response['generalLogic'][$general_count]['banner']['bannerImage'] = $url;         
               }

              if ($banner_data->get('field_bannertext')->value != NULL) {
                $response['generalLogic'][$general_count]['banner']['bannerText'] = $banner_data->get('field_bannertext')->value;
              }             
              $banner_count++;
            
            //buttons Paragraph 
            $button_items = $banner_data->field_buttons->getValue();            
            $button_count = 0;
            foreach ($button_items as $button_item) {
                $button_data = Paragraph::load($button_item['target_id']);
                if ($button_data->get('field_btnlabel')->value != NULL) {
                  $response['generalLogic'][$general_count]['banner']['buttons'][$button_count]['btnLabel'] = $button_data->get('field_btnlabel')->value;
                  $response['generalLogic'][$general_count]['banner']['buttons'][$button_count]['schemeCode'] = $button_data->get('field_schemecode_')->value;
                  $response['generalLogic'][$general_count]['banner']['buttons'][$button_count]['transactionType'] = $button_data->get('field_transactiontype')->value;
                  $response['generalLogic'][$general_count]['banner']['buttons'][$button_count]['type'] = $button_data->get('field_type')->value;
                }
                $button_count++;
            }

            }//Banner Paragraph End



                  //POPUP MODEL Paragraph 
                  $popup_items = $p->field_popup_->getValue();
                  $popup_count = 0;
                  foreach ($popup_items as $popup_item) {
                      $popup_data = Paragraph::load($popup_item['target_id']);               
                      // echo '<pre>';print_r($popup_data);exit;
                    if ($popup_data->field_popupimage->getValue() != NULL) {
                        $image_id = $popup_data->field_popupimage->getValue();
                        $uri = $popup_data->get('field_popupimage')->entity->getFileUri();
                        $url = file_create_url($uri);
                        $response['generalLogic'][$general_count]['popup']['popupImage'] = $url;         
                     }
      
                    if ($popup_data->get('field_popuptext')->value != NULL) {
                      $response['generalLogic'][$general_count]['popup']['popupText'] = $popup_data->get('field_popuptext')->value;
                    }             
                    $banner_count++;
                  
                  //buttons Paragraph 
                  $button_items = $popup_data->field_buttons_popup->getValue();            
                  $button_count = 0;
                  foreach ($button_items as $button_item) {
                      $button_data = Paragraph::load($button_item['target_id']);
                      // echo '<pre>';print_r($button_data);exit;
                      if ($button_data->get('field_btnlabel')->value != NULL) {
                        $response['generalLogic'][$general_count]['popup']['buttons'][$button_count]['btnLabel'] = $button_data->get('field_btnlabel')->value;
                        $response['generalLogic'][$general_count]['popup']['buttons'][$button_count]['schemeCode'] = $button_data->get('field_schemecode_')->value;
                        $response['generalLogic'][$general_count]['popup']['buttons'][$button_count]['transactionType'] = $button_data->get('field_transactiontype')->value;
                        $response['generalLogic'][$general_count]['popup']['buttons'][$button_count]['type'] = $button_data->get('field_type')->value;
                      }
                      $button_count++;
                  }
      
                  }//POPUP MODEL Paragraph End
                   
                  //Alerts MODEL Paragraph 
                            $alter_items = $p->field_alerts->getValue();
                            $alter_count = 0;
                            foreach ($alter_items as $alter_item) {
                                $alter_data = Paragraph::load($alter_item['target_id']);               
                                // echo '<pre>';print_r($alter_data);exit;                     
                              if ($alter_data->get('field_alertdisplaylabel')->value != NULL) {
                                $response['generalLogic'][$general_count]['alerts'][$alter_count]['alertDisplayLabel'] = $alter_data->get('field_alertdisplaylabel')->value;
                                $response['generalLogic'][$general_count]['alerts'][$alter_count]['fromSchemeCode'] = $alter_data->get('field_fromschemecode')->value;
                                $response['generalLogic'][$general_count]['alerts'][$alter_count]['fromSchemeCategory'] = $alter_data->get('field_fromschemecategory')->value;
                                $response['generalLogic'][$general_count]['alerts'][$alter_count]['transactionType'] = $alter_data->get('field_transactiontype_alters')->value;
                                $response['generalLogic'][$general_count]['alerts'][$alter_count]['toSchemeCode'] = $alter_data->get('field_toschemecode')->value;
                                $response['generalLogic'][$general_count]['alerts'][$alter_count]['toSchemeCategory'] = $alter_data->get('field_toschemecategory')->value;
                              }             
                              $alter_count++;                          
                    
                
                    }//Alerts MODEL Paragraph End

                    // echo '<pre>';print_r($p);exit;  
                     //Schemes MODEL Paragraph 
                     $scheme_items = $p->field_recschemes_generallogic->getValue();
                     $scheme_count = 0;
                     foreach ($scheme_items as $scheme_item) {
                         $scheme_data = Paragraph::load($scheme_item['target_id']);               
                         //echo '<pre>';print_r($scheme_data);exit;                     
                       if ($scheme_data->get('field_schemecode_')->value != NULL) {
                         $response['generalLogic'][$general_count]['recSchemes'][$scheme_count]['schemeCode'] = $scheme_data->get('field_schemecode_')->value;
                         $response['generalLogic'][$general_count]['recSchemes'][$scheme_count]['order'] = $scheme_data->get('field_order')->value;
                       
                       }             
                       $scheme_count++;                          
             
         
                      }//Schemes MODEL Paragraph End

                      $general_count++;

          } //Main Paragraph



          }



        }
        else {
          $response['valid'] = "false";
        }
    
        $offer_data_json = new JsonResponse($response);
      }//Getting Node id by using query end loop

      //echo '<pre>';print_r($offer_data_json);exit;
    return $offer_data_json;
  }

}